# Database Setup Guide

## Struktur Database

Database ini mengintegrasikan Supabase Auth dengan custom tables.

### Tabel Utama:

- `users` - Linked ke `auth.users` (Supabase Auth) dengan UUID
- `role` - Role management (user, creator, admin)
- `link` - Short link management
- `link_click` - Analytics untuk link clicks
- `twibone` - Twibbon/frame management
- `twibone_used` - Analytics untuk twibbon usage
- `creator_data` - Extended data untuk creators

## Cara Setup

### 1. Jalankan setup.sql

Buka Supabase Dashboard → SQL Editor → Jalankan file `setup.sql`

```sql
-- File ini akan membuat semua tabel dengan relasi
```

### 2. Jalankan seed-roles.sql

Insert role default:

```sql
-- File ini akan membuat role: user, creator, admin
```

### 3. Jalankan auth-trigger.sql

Setup trigger untuk auto-create user:

```sql
-- File ini akan:
-- 1. Membuat function handle_new_user()
-- 2. Membuat trigger on_auth_user_created
-- 3. Membuat function handle_updated_at()
-- 4. Membuat trigger set_updated_at
```

## Cara Kerja Auth Integration

1. **User Register via Supabase Auth**

   - User register menggunakan `supabase.auth.signUp()`
   - Supabase membuat record di `auth.users`

2. **Trigger Otomatis**

   - Trigger `on_auth_user_created` akan berjalan
   - Function `handle_new_user()` dipanggil
   - Record baru dibuat di tabel `users` dengan:
     - `uid` = UUID dari `auth.users.id`
     - `name` = dari metadata atau email
     - `email` = dari auth email
     - `role_uid` = default role 'user' (uid = 1)

3. **Relasi ke Tabel Lain**
   - Tabel `link`, `twibone`, `creator_data` mereferensi `users.uid`
   - Saat user dihapus dari auth, record di `users` juga terhapus (CASCADE)

## Tipe Data Penting

- `users.uid` = **UUID** (sama dengan `auth.users.id`)
- Semua `*_uid` yang mereferensi users menggunakan **UUID**
- Role dan ID lainnya menggunakan **BIGINT**

## Row Level Security (RLS)

Untuk keamanan tambahan, aktifkan RLS pada tabel:

```sql
-- Enable RLS untuk tabel users
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- Policy: Users can read their own data
CREATE POLICY "Users can read own data" ON users
    FOR SELECT
    USING (auth.uid() = uid);

-- Policy: Users can update their own data
CREATE POLICY "Users can update own data" ON users
    FOR UPDATE
    USING (auth.uid() = uid);

-- Ulangi untuk tabel link, twibone, dll sesuai kebutuhan
```

## Catatan

- Pastikan role default sudah ada sebelum user pertama register
- Jika ingin mengubah default role, edit function `handle_new_user()`
- Untuk testing, bisa langsung insert ke `auth.users` via Supabase Dashboard
