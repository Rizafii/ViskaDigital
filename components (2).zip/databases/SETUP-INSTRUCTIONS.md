# Database Setup Guide - FIXED VERSION

## 🔴 Masalah yang Diperbaiki

1. **Primary Key tidak auto-increment** - Semua tabel dengan BIGINT sekarang menggunakan `BIGSERIAL` untuk auto-increment
2. **Foreign Key constraints** - Ditambahkan `ON DELETE CASCADE` untuk menghindari orphaned records
3. **Missing error handling** - Trigger sekarang memiliki error handling yang lebih baik
4. **Display name support** - Trigger mendukung `display_name` dari user metadata

## 📋 Cara Setup Database (URUTAN PENTING!)

### Step 1: Drop dan Recreate Tables (jika sudah ada)

⚠️ **WARNING: Ini akan menghapus semua data!**

Jika database sudah ada dan bermasalah, uncomment bagian DROP di `setup-fixed.sql`:

```sql
DROP TABLE IF EXISTS "creator_data" CASCADE;
DROP TABLE IF EXISTS "twibone_used" CASCADE;
DROP TABLE IF EXISTS "link_click" CASCADE;
DROP TABLE IF EXISTS "link" CASCADE;
DROP TABLE IF EXISTS "twibone" CASCADE;
DROP TABLE IF EXISTS "users" CASCADE;
DROP TABLE IF EXISTS "role" CASCADE;
```

### Step 2: Jalankan File SQL di Supabase

Buka **Supabase Dashboard** → **SQL Editor** → **New Query**

#### 1. Jalankan `setup-fixed.sql`

```sql
-- Copy-paste seluruh isi setup-fixed.sql
-- File ini akan membuat:
-- ✓ Table role (dengan BIGSERIAL)
-- ✓ Table users (linked ke auth.users)
-- ✓ Table link (dengan BIGSERIAL)
-- ✓ Table link_click (dengan BIGSERIAL)
-- ✓ Table twibone (dengan BIGSERIAL)
-- ✓ Table twibone_used (dengan BIGSERIAL)
-- ✓ Table creator_data (dengan BIGSERIAL)
-- ✓ Indexes untuk performa
```

#### 2. Jalankan `seed-roles.sql`

```sql
-- Insert default roles
INSERT INTO "role" (uid, role_name, created_at, updated_at) VALUES
(1, 'user', NOW(), NOW()),
(2, 'creator', NOW(), NOW()),
(3, 'admin', NOW(), NOW())
ON CONFLICT (role_name) DO NOTHING;
```

#### 3. Jalankan `auth-trigger-fixed.sql`

```sql
-- Copy-paste seluruh isi auth-trigger-fixed.sql
-- File ini akan membuat:
-- ✓ Function handle_new_user() dengan error handling
-- ✓ Trigger on_auth_user_created
-- ✓ Function handle_updated_at()
-- ✓ Triggers untuk auto-update updated_at
```

### Step 3: Verifikasi Setup

Jalankan query ini untuk memastikan semua sudah benar:

```sql
-- Cek apakah roles sudah ada
SELECT * FROM "role";

-- Cek apakah trigger sudah terpasang
SELECT
    trigger_name,
    event_manipulation,
    event_object_table,
    action_statement
FROM information_schema.triggers
WHERE trigger_schema = 'public' OR event_object_schema = 'auth';

-- Cek sequences (auto-increment)
SELECT
    schemaname,
    sequencename,
    last_value
FROM pg_sequences
WHERE schemaname = 'public';
```

## 🧪 Test Registration

Setelah setup, test dengan mendaftar user baru dari aplikasi atau Supabase Dashboard:

### Test dari Aplikasi:

1. Buka form register
2. Isi: Nama Lengkap, Email, Password
3. Klik Daftar
4. Cek email untuk verifikasi

### Test dari Supabase Dashboard:

1. **Authentication** → **Users** → **Add user**
2. Email: `test@example.com`
3. Password: `test123456`
4. User Metadata (JSON):

```json
{
  "display_name": "Test User",
  "full_name": "Test User"
}
```

5. Klik **Create user**
6. Cek tabel `users` - seharusnya otomatis terisi

### Verify di SQL Editor:

```sql
-- Cek apakah user berhasil dibuat di tabel users
SELECT
    u.uid,
    u.name,
    u.email,
    r.role_name,
    u.created_at
FROM users u
JOIN role r ON u.role_uid = r.uid;
```

## 🔍 Troubleshooting

### Error: "Database error saving new user"

**Kemungkinan penyebab:**

1. **Role belum di-seed**

   ```sql
   -- Jalankan seed-roles.sql lagi
   INSERT INTO "role" (role_name) VALUES ('user')
   ON CONFLICT (role_name) DO NOTHING;
   ```

2. **Trigger tidak aktif**

   ```sql
   -- Cek trigger
   SELECT * FROM pg_trigger WHERE tgname = 'on_auth_user_created';

   -- Jika tidak ada, jalankan auth-trigger-fixed.sql lagi
   ```

3. **Constraint violation**
   ```sql
   -- Cek Supabase logs di Dashboard → Logs → Postgres Logs
   ```

### Error: "Failed to create user: Database error creating new user"

Ini biasanya karena:

- Email sudah terdaftar
- Role default tidak ditemukan
- Foreign key constraint gagal

**Solusi:**

```sql
-- Cek apakah email sudah ada
SELECT * FROM users WHERE email = 'email@example.com';

-- Cek apakah role 'user' ada
SELECT * FROM role WHERE role_name = 'user';

-- Lihat error detail di Supabase Dashboard → Logs
```

## 📊 Perbedaan dengan File Lama

| Aspek          | File Lama       | File Baru (Fixed)                   |
| -------------- | --------------- | ----------------------------------- |
| Primary Key    | `BIGINT` manual | `BIGSERIAL` auto-increment          |
| Foreign Key    | Tanpa CASCADE   | Dengan `ON DELETE CASCADE`          |
| Error Handling | Tidak ada       | Ada exception handling              |
| Display Name   | Hanya full_name | display_name + full_name + fallback |
| Indexes        | Tidak ada       | Ada untuk performa                  |
| Triggers       | Hanya users     | Semua tabel                         |

## 🚀 Next Steps

Setelah database setup berhasil:

1. ✅ Test registration dari aplikasi
2. ✅ Test login
3. ✅ Cek apakah user metadata tersimpan
4. ✅ Test create link/twibbon (ketika fitur sudah ready)

## 📝 Notes

- Gunakan file `-fixed.sql` untuk setup baru
- File lama (`setup.sql`, `auth-trigger.sql`) tidak digunakan lagi
- Backup data sebelum drop tables
- Jalankan seed-roles.sql sebelum auth-trigger-fixed.sql
